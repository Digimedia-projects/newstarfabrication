// Wait for 5 seconds to show the popup
window.addEventListener('load', () => {
  const popup = document.getElementById('popup');
  const closePopupButton = document.getElementById('close-popup');
  
  // Show the popup after 5 seconds
  setTimeout(() => {
    popup.classList.remove('hidden');
  }, 5000);

  // Close the popup when the close button is clicked
  closePopupButton.addEventListener('click', () => {
    popup.classList.add('hidden');
  });
});